term.clear()
term.setCursorPos( 1, 1 )
