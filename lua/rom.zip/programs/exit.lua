shell.exit()
